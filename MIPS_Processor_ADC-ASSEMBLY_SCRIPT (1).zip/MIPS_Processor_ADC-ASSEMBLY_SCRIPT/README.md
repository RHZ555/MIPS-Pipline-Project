<h1>Assembly code</h1>
<p>Small and simple MIPS assembly script made to apply a Caesar cipher over a word.</p>
<p>Base inspiration and code for the instruction set used for the main processor.</p>
<h3>Check [MIPS_PROJECT] and [MIPS_DECODER] branches for more information.</h3>
