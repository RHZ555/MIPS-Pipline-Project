<h1>Branch: MIPS_PROJECT</h1>
<p>Main submittable, simple implementation for a MIPS processor.</p>
<p>Able to handle R, I and J type instructions</p>
<h2>Files: .v</h2>
<p>Verilog modules and source code.</p>
<h2>Files: others</h2>
<p>Files and folders required for synthesis inisde the XILINX suite.</p>
<h2>Files: .xise</h2>
<p>Main project file for ISE 14.7</p>
